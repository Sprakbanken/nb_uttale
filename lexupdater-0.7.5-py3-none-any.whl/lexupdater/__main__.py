"""Run the lexupdater.main() function."""

from .lexupdater import main

if __name__ == '__main__':
    main()
